﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EstateAgency.Windows
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Frame.Content = new ClientsPage();
            Frame.NavigationService.RemoveBackEntry();
        }

        private void ClientsWindow_Click(object sender, RoutedEventArgs e)
        {
            Title = "Клиенты";
            Frame.Content = new ClientsPage();
            Frame.NavigationService.RemoveBackEntry();
        }

        private void AgentsWindow_Click(object sender, RoutedEventArgs e)
        {
            Title = "Риэлторы";
            Frame.Content = new AgentsPage();
            Frame.NavigationService.RemoveBackEntry();
        }

        private void EstatesWindow_Click(object sender, RoutedEventArgs e)
        {
            Title = "Недвижимости";
            Frame.Content = new EstatesPage();
            Frame.NavigationService.RemoveBackEntry();
        }

        private void DemandsWindow_Click(object sender, RoutedEventArgs e)
        {
            Title = "Спросы";
            Frame.Content = new DemandsPage();
            Frame.NavigationService.RemoveBackEntry();
        }

        private void OffersWindow_Click(object sender, RoutedEventArgs e)
        {
            Title = "Предложения";
            Frame.Content = new OffersPage();
            Frame.NavigationService.RemoveBackEntry();
        }
    }
}
