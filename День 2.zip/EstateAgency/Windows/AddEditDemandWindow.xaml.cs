﻿using EstateAgency.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EstateAgency.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddEditDemandWindow.xaml
    /// </summary>
    public partial class AddEditDemandWindow : Window
    {
        private Demand _demand;
        private Entities _entities;

        public AddEditDemandWindow(Demand demand, Entities entities)
        {
            InitializeComponent();

            _demand = demand;
            _entities = entities;

            //Заполнение комбо-боксов
            EstateTypeInput.DisplayMemberPath = "Name";
            EstateTypeInput.SelectedValuePath = "Id";
            EstateTypeInput.ItemsSource = _entities.EstateType.ToList();

            AgentInput.DisplayMemberPath = "FirstName";
            AgentInput.SelectedValuePath = "Id";
            AgentInput.ItemsSource = _entities.User.Where(x => x.UserTypeId == 2).ToList();

            ClientInput.DisplayMemberPath = "FirstName";
            ClientInput.SelectedValuePath = "Id";
            ClientInput.ItemsSource = _entities.User.Where(x => x.UserTypeId == 3).ToList();

            //Вывод первоначальных данных, если идет редактирование
            if (_demand.Id != 0)
            {
                AddressCityInput.Text = _demand.AddressCity;
                AddressStreetInput.Text = _demand.AddressStreet;
                AddressHouseInput.Text = _demand.AddressHouse.ToString();
                AddressNumberInput.Text = _demand.AddressNumber.ToString();
                MinPriceInput.Text = _demand.MinPrice.ToString();
                MaxPriceInput.Text = _demand.MaxPrice.ToString();
                MinAreaInput.Text = _demand.MinArea.ToString();
                MaxAreaInput.Text = _demand.MaxArea.ToString();
                MinFloors.Text = _demand.MinFloors.ToString();
                MaxFloors.Text = _demand.MaxFloors.ToString();
                MinRooms.Text = _demand.MinRooms.ToString();
                MaxRooms.Text = _demand.MaxRooms.ToString();
                MinFloor.Text = _demand.MinFloor.ToString();
                MaxFloor.Text = _demand.MaxFloor.ToString();
                AgentInput.Text = _demand.User == null ? string.Empty : _demand.User.FirstName;
                ClientInput.Text = _demand.User1.FirstName;
                EstateTypeInput.Text = _demand.EstateType == null ? string.Empty : _demand.EstateType.Name;
            }
        }

        private bool CheckNumber(string number, out double? convertedNumber)
        {
            if (number == string.Empty)
            {
                convertedNumber = null;
                return true;
            }

            try
            {
                convertedNumber = Convert.ToDouble(number);
                return true;
            }
            catch
            {
                convertedNumber = null;
                return false;
            }
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            if (ClientInput.Text == string.Empty)
            {
                MessageBox.Show("Клиент обязателен для заполнения",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            if (!CheckNumber(AddressHouseInput.Text, out double? addressHouse) ||
                !CheckNumber(AddressNumberInput.Text, out double? addressNumber) ||
                !CheckNumber(MinPriceInput.Text, out double? minPrice) ||
                !CheckNumber(MaxPriceInput.Text, out double? maxPrice) ||
                !CheckNumber(MinAreaInput.Text, out double? minArea) ||
                !CheckNumber(MaxAreaInput.Text, out double? maxArea) ||
                !CheckNumber(MinFloors.Text, out double? minFloors) ||
                !CheckNumber(MaxFloors.Text, out double? maxFloors) ||
                !CheckNumber(MinRooms.Text, out double? minRooms) ||
                !CheckNumber(MaxRooms.Text, out double? maxRooms) ||
                !CheckNumber(MinFloor.Text, out double? minFloor) ||
                !CheckNumber(MaxFloor.Text, out double? maxFloor))
            {
                MessageBox.Show("Данные заполнены некорректно",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            //Сохранение в БД
            _demand.AddressCity = AddressCityInput.Text;
            _demand.AddressStreet = AddressStreetInput.Text;
            _demand.AddressHouse = (int?)addressHouse;
            _demand.AddressNumber = (int?)addressNumber;
            _demand.MinPrice = minPrice;
            _demand.MaxPrice = maxPrice;
            _demand.MinArea = minArea;
            _demand.MaxArea = maxArea;
            _demand.MinFloors = (int?)minFloors;
            _demand.MaxFloors = (int?)maxFloors;
            _demand.MinRooms = (int?)minRooms;
            _demand.MaxRooms = (int?)maxRooms;
            _demand.MinFloor = (int?)minFloor;
            _demand.MaxFloor = (int?)maxFloor;
            _demand.AgentId = (int?)AgentInput.SelectedValue;
            _demand.ClientId = (int)ClientInput.SelectedValue;
            _demand.EstateTypeId = (int?)EstateTypeInput.SelectedValue;

            if (_demand.Id == 0)
            {
                if (_entities.Demand.Count() == 0)
                {
                    _demand.Id = 1;
                    _entities.Demand.Add(_demand);
                }
                else
                {
                    var id = _entities.Demand.Max(x => x.Id) + 1;
                    _demand.Id = id;
                    _entities.Demand.Add(_demand);
                }
            }

            _entities.SaveChanges();

            DialogResult = true;
        }

        private void Deny_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
