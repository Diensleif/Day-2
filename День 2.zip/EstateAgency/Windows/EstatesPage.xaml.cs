﻿using EstateAgency.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EstateAgency.Windows
{
    /// <summary>
    /// Логика взаимодействия для EstatesPage.xaml
    /// </summary>
    public partial class EstatesPage : Page
    {
        private Entities _entities = new Entities();

        public EstatesPage()
        {
            InitializeComponent();
            
            //Вывод типов недвижимостей в комбо-бокс
            EstateTypeInput.ItemsSource = _entities.EstateType.Select(x => x.Name).ToList();

            //Вывод всех недвижимостей в дата-грид
            Estates.ItemsSource = _entities.Estate.ToList();
        }

        //Вывод недвижимостей в соответствии с искомым адресом и фильтрацией по типу
        private void FilterEstates(string findInput, string estateTypeInput)
        {
            var estates = _entities.Estate.ToList();

            if (findInput != string.Empty)
            {
                estates = estates
                    .Where(x =>
                           x.AddressCity.Contains(findInput) ||
                           x.AddressStreet.Contains(findInput)
                           )
                    .ToList();
            }

            if (estateTypeInput != string.Empty)
            {
                estates = estates
                    .Where(x => x.EstateType.Name == estateTypeInput)
                    .ToList();
            }

            Estates.ItemsSource = estates;
        }

        private void FindInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            FilterEstates(FindInput.Text, EstateTypeInput.Text);
        }

        private void EstateTypeInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterEstates(FindInput.Text, e.AddedItems[0] as  string);
        }

        //Открытие окна добавления недвижимости
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var addEditEstateWindow = new AddEditEstateWindow(new Estate(), _entities);
            if (addEditEstateWindow.ShowDialog() == true)
            {
                FilterEstates(FindInput.Text, EstateTypeInput.Text);
            }
        }

        //Открытие окна редактирования недвижимости
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var estate = Estates.SelectedItem as Estate;

            if (estate == null)
            {
                MessageBox.Show("Сначала выберите недвижимость",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var addEditEstateWindow = new AddEditEstateWindow(estate, _entities);
            if (addEditEstateWindow.ShowDialog() == true)
            {
                FilterEstates(FindInput.Text, EstateTypeInput.Text);
            }
        }

        //Удаление недвижимости
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var estate = Estates.SelectedItem as Estate;

            if (estate == null)
            {
                MessageBox.Show("Сначала выберите недвижимость",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (estate.Offer.Count == 0)
            {
                if (MessageBox.Show("Вы уверены?",
                   "Внимание",
                   MessageBoxButton.YesNo,
                   MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    _entities.Estate.Remove(estate);
                    _entities.SaveChanges();

                    FilterEstates(FindInput.Text, EstateTypeInput.Text);
                }
            }
            else
            {
                MessageBox.Show("Нельзя удалить эту недвижимость из-за связей в БД",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
