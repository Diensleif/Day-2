﻿using EstateAgency.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EstateAgency.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddEditEstateWindow.xaml
    /// </summary>
    public partial class AddEditEstateWindow : Window
    {
        private Estate _estate;
        private Entities _entities;

        public AddEditEstateWindow(Estate estate, Entities entities)
        {
            InitializeComponent();

            _estate = estate;
            _entities = entities;

            //Заполнение комбо-бокса с типами недвижимости
            EstateTypeInput.DisplayMemberPath = "Name";
            EstateTypeInput.SelectedValuePath = "Id";
            EstateTypeInput.ItemsSource = _entities.EstateType.ToList();

            //Вывод первоначальных данных, если идет редактирование
            if (_estate.Id != 0)
            {
                AddressCityInput.Text = _estate.AddressCity;
                AddressStreetInput.Text = _estate.AddressStreet;
                AddressHouseInput.Text = _estate.AddressHouse.ToString();
                AddressNumberInput.Text = _estate.AddressNumber.ToString();
                CoordinateLatitudeInput.Text = _estate.CoordinateLatitude.ToString();
                CoordinateLongitudeInput.Text = _estate.CoordinateLongitude.ToString();
                TotalAreaInput.Text = _estate.TotalArea.ToString();
                TotalFloorsInput.Text = _estate.TotalFloors.ToString();
                RoomsInput.Text = _estate.Rooms.ToString();
                FloorInput.Text = _estate.Floor.ToString();
                EstateTypeInput.Text = _estate.EstateType.Name;
            }
        }

        private bool CheckNumber(string number, out double? convertedNumber)
        {
            if (number == string.Empty)
            {
                convertedNumber = null;
                return true;
            }

            try
            {
                convertedNumber = Convert.ToDouble(number);
                return true;
            }
            catch
            {
                convertedNumber = null;
                return false;
            }
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            if (AddressCityInput.Text == string.Empty ||
                AddressStreetInput.Text == string.Empty ||
                AddressHouseInput.Text == string.Empty ||
                AddressNumberInput.Text == string.Empty ||
                EstateTypeInput.Text == string.Empty)
            {
                MessageBox.Show("Адрес и тип недвижимости обязательны для заполнения",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            if (!CheckNumber(AddressHouseInput.Text, out double? addressHouse) ||
                !CheckNumber(AddressNumberInput.Text, out double? addressNumber) ||
                !CheckNumber(CoordinateLatitudeInput.Text, out double? coordinateLatitude) ||
                !CheckNumber(CoordinateLongitudeInput.Text, out double? coordinateLongitude) ||
                !CheckNumber(TotalAreaInput.Text, out double? totalArea) ||
                !CheckNumber(TotalFloorsInput.Text, out double? totalFloors) ||
                !CheckNumber(RoomsInput.Text, out double? rooms) ||
                !CheckNumber(FloorInput.Text, out double? floor))
            {
                MessageBox.Show("Данные заполнены некорректно",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            //Сохранение в БД
            _estate.AddressCity = AddressCityInput.Text;
            _estate.AddressStreet = AddressStreetInput.Text;
            _estate.AddressHouse = (int?)addressHouse;
            _estate.AddressNumber = (int?)addressNumber;
            _estate.CoordinateLatitude = coordinateLatitude;
            _estate.CoordinateLongitude = coordinateLongitude;
            _estate.TotalArea = totalArea;
            _estate.TotalFloors = (int?)totalFloors;
            _estate.Rooms = (int?)rooms;
            _estate.Floor = (int?)floor;
            _estate.EstateTypeId = (int)EstateTypeInput.SelectedValue;


            if (_estate.Id == 0)
            {

                if (_entities.Estate.Count() == 0)
                {
                    _estate.Id = 1;
                    _entities.Estate.Add(_estate);
                }
                else
                {
                    var id = _entities.Estate.Max(x => x.Id) + 1;
                    _estate.Id = id;
                    _entities.Estate.Add(_estate);
                }
            }

            _entities.SaveChanges();

            DialogResult = true;
        }

        private void Deny_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
