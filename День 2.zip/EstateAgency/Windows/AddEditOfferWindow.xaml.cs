﻿using EstateAgency.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EstateAgency.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddEditOfferWindow.xaml
    /// </summary>
    public partial class AddEditOfferWindow : Window
    {
        private Offer _offer;
        private Entities _entities;

        public AddEditOfferWindow(Offer offer, Entities entities)
        {
            InitializeComponent();

            _offer = offer;
            _entities = entities;

            EstateInput.DisplayMemberPath = "Addreess";
            EstateInput.SelectedValuePath = "Id";
            EstateInput.ItemsSource = _entities.Estate.ToList();

            AgentInput.DisplayMemberPath = "FirstName";
            AgentInput.SelectedValuePath = "Id";
            AgentInput.ItemsSource = _entities.User.Where(x => x.UserTypeId == 2).ToList();

            ClientInput.DisplayMemberPath = "FirstName";
            ClientInput.SelectedValuePath = "Id";
            ClientInput.ItemsSource = _entities.User.Where(x => x.UserTypeId == 3).ToList();

            //Вывод первоначальных данных, если идет редактирование
            if (_offer.Id != 0)
            {
                PriceInput.Text = _offer.Price.ToString();
                AgentInput.Text = _offer.User == null? string.Empty : _offer.User.FirstName;
                ClientInput.Text = _offer.User1.FirstName;
                EstateInput.Text = _offer.Estate.Addreess;
            }
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            if (PriceInput.Text == string.Empty ||
                ClientInput.Text == string.Empty ||
                EstateInput.Text == string.Empty)
            {
                MessageBox.Show("Все поля, кроме агента, обязательны для заполнения",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                Convert.ToDouble(PriceInput.Text);
            }
            catch
            {
                MessageBox.Show("Некорректная цена",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //Сохранение в БД
            _offer.Price = Convert.ToDouble(PriceInput.Text);
            _offer.AgentId = (int?)AgentInput.SelectedValue;
            _offer.ClientId = (int)ClientInput.SelectedValue;
            _offer.EstateId = (int)EstateInput.SelectedValue;

            if (_offer.Id == 0)
            {
                if (_entities.Offer.Count() == 0)
                {
                    _offer.Id = 1;
                    _entities.Offer.Add(_offer);
                }
                else
                {
                    var id = _entities.Offer.Max(x => x.Id) + 1;
                    _offer.Id = id;
                    _entities.Offer.Add(_offer);
                }
            }

            _entities.SaveChanges();

            DialogResult = true;
        }

        private void Deny_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
