﻿using EstateAgency.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EstateAgency.Windows
{
    /// <summary>
    /// Логика взаимодействия для DemandsPage.xaml
    /// </summary>
    public partial class DemandsPage : Page
    {
        private Entities _entities = new Entities();

        public DemandsPage()
        {
            InitializeComponent();

            //Вывод всех спросов в дата-грид
            Demands.ItemsSource = _entities.Demand.ToList();
        }

        //Вывод спросов в соответствии с искомым адресом
        private void FilterDemands(string findInput)
        {
            var demands = _entities.Demand.ToList();

            if (findInput != string.Empty)
            {
                demands = demands
                    .Where(x =>
                           x.AddressCity.Contains(findInput) ||
                           x.AddressStreet.Contains(findInput)
                           )
                    .ToList();
            }

            Demands.ItemsSource = demands;
        }

        private void FindInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            FilterDemands(FindInput.Text);
        }

        //Открытие окна добавления спроса
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var addEditDemandWindow = new AddEditDemandWindow(new Demand(), _entities);
            if (addEditDemandWindow.ShowDialog() == true)
            {
                FilterDemands(FindInput.Text);
            }
        }

        //Открытие окна редактирования спроса
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var demand = Demands.SelectedItem as Demand;

            if (demand == null)
            {
                MessageBox.Show("Сначала выберите спрос",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var addEditDemandWindow = new AddEditDemandWindow(demand, _entities);
            if (addEditDemandWindow.ShowDialog() == true)
            {
                FilterDemands(FindInput.Text);
            }
        }

        //Удаление спроса
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var demand = Demands.SelectedItem as Demand;

            if (demand == null)
            {
                MessageBox.Show("Сначала выберите спрос",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (demand.Deal.Count == 0)
            {
                if (MessageBox.Show("Вы уверены?",
                   "Внимание",
                   MessageBoxButton.YesNo,
                   MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    _entities.Demand.Remove(demand);
                    _entities.SaveChanges();

                    FilterDemands(FindInput.Text);
                }
            }
            else
            {
                MessageBox.Show("Нельзя удалить этот спрос из-за связей в БД",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
