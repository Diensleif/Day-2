﻿using EstateAgency.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EstateAgency.Windows
{
    /// <summary>
    /// Логика взаимодействия для OffersPage.xaml
    /// </summary>
    public partial class OffersPage : Page
    {
        private Entities _entities = new Entities();

        public OffersPage()
        {
            InitializeComponent();

            Offers.ItemsSource = _entities.Offer.ToList();
        }

        private void FindInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            var text = FindInput.Text;
            if (text == string.Empty)
            {
                Offers.ItemsSource = _entities.Offer.ToList();
            }
            else
            {
                Offers.ItemsSource = _entities.Offer
                    .Where(x => x.Estate.AddressCity.Contains(text) ||
                    x.Estate.AddressStreet.Contains(text) ||
                    x.Estate.AddressHouse.ToString().Contains(text) ||
                    x.Estate.AddressNumber.ToString().Contains(text))
                    .ToList();
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var addEditOfferWindow = new AddEditOfferWindow(new Offer(), _entities);
            if (addEditOfferWindow.ShowDialog() == true)
            {
                FindInput_TextChanged(null, null);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var offer = Offers.SelectedItem as Offer;

            if (offer == null)
            {
                MessageBox.Show("Сначала выберите предложение",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var addEditOfferWindow = new AddEditOfferWindow(offer, _entities);
            if (addEditOfferWindow.ShowDialog() == true)
            {
                FindInput_TextChanged(null, null);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var offer = Offers.SelectedItem as Offer;

            if (offer == null)
            {
                MessageBox.Show("Сначала выберите предложение",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (offer.Deal.Count == 0)
            {
                if (MessageBox.Show("Вы уверены?",
                   "Внимание",
                   MessageBoxButton.YesNo,
                   MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    _entities.Offer.Remove(offer);
                    _entities.SaveChanges();

                    FindInput_TextChanged(null, null);
                }
            }
            else
            {
                MessageBox.Show("Нельзя удалить это предложение из-за связей в БД",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
